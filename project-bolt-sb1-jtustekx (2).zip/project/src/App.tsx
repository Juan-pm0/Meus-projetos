import React, { useState } from 'react';
import { Menu, X, ArrowUpRight, Globe, Mail, Github, Linkedin } from 'lucide-react';

function App() {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <div className="bg-[#111] min-h-screen text-white">
      {/* Header */}
      <header className="fixed w-full top-0 z-50 bg-[#111]/80 backdrop-blur-sm">
        <div className="container mx-auto px-6 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-light">Seu Nome</h1>
          <button 
            onClick={() => setMenuOpen(!menuOpen)}
            className="p-2 hover:bg-white/10 rounded-full transition-colors"
          >
            {menuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </header>

      {/* Menu Mobile */}
      {menuOpen && (
        <div className="fixed inset-0 bg-[#111] z-40 pt-20">
          <nav className="container mx-auto px-6 py-8">
            <ul className="space-y-6 text-4xl font-light">
              <li><a href="#sobre" className="hover:text-gray-400 transition-colors" onClick={() => setMenuOpen(false)}>Sobre</a></li>
              <li><a href="#projetos" className="hover:text-gray-400 transition-colors" onClick={() => setMenuOpen(false)}>Projetos</a></li>
              <li><a href="#contato" className="hover:text-gray-400 transition-colors" onClick={() => setMenuOpen(false)}>Contato</a></li>
            </ul>
          </nav>
        </div>
      )}

      {/* Hero Section */}
      <section className="pt-32 pb-20 px-6">
        <div className="container mx-auto">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <div className="flex items-center gap-4 mb-8">
                <Globe size={24} className="text-blue-500" />
                <span className="text-gray-400">Localizado em São Paulo, Brasil</span>
              </div>
              <h1 className="text-6xl md:text-7xl font-light mb-8">
                Vamos trabalhar juntos
              </h1>
              <p className="text-xl text-gray-400 max-w-2xl">
                Ajudando marcas a se destacarem na era digital.
                Juntos, vamos definir um novo padrão. Sem rodeios,
                sempre na vanguarda.
              </p>
            </div>
            <div className="relative">
              <div className="aspect-[3/4] rounded-2xl overflow-hidden bg-neutral-900">
                <img 
                  src="https://images.unsplash.com/photo-1707343843437-caacff5cfa74" 
                  alt="Desenvolvedor" 
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="absolute -bottom-6 -right-6 bg-blue-500 text-white py-4 px-6 rounded-lg">
                <p className="text-sm font-medium">Desenvolvedor Full Stack</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Projetos */}
      <section id="projetos" className="py-20 px-6">
        <div className="container mx-auto">
          <h2 className="text-2xl font-light mb-12">Projetos Recentes</h2>
          <div className="grid gap-12">
            {projects.map((project, index) => (
              <div key={index} className="group">
                <div className="relative overflow-hidden">
                  <img 
                    src={project.image} 
                    alt={project.title}
                    className="w-full aspect-video object-cover rounded-lg"
                  />
                  <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <ArrowUpRight size={32} />
                  </div>
                </div>
                <div className="mt-4 flex justify-between items-center">
                  <h3 className="text-2xl font-light">{project.title}</h3>
                  <p className="text-gray-400">{project.type}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contato */}
      <section id="contato" className="py-20 px-6 bg-neutral-900">
        <div className="container mx-auto">
          <h2 className="text-4xl md:text-6xl font-light mb-12">Entre em contato</h2>
          <div className="flex flex-col md:flex-row gap-8">
            <a href="mailto:seu@email.com" className="flex items-center gap-4 text-xl hover:text-gray-400 transition-colors">
              <Mail size={24} />
              seu@email.com
            </a>
            <div className="flex gap-6">
              <a href="https://github.com" target="_blank" rel="noopener noreferrer" className="hover:text-gray-400 transition-colors">
                <Github size={24} />
              </a>
              <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer" className="hover:text-gray-400 transition-colors">
                <Linkedin size={24} />
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-6 border-t border-neutral-800">
        <div className="container mx-auto flex justify-between items-center text-sm text-gray-400">
          <p>© {new Date().getFullYear()} Seu Nome</p>
          <p>Desenvolvedor & Designer</p>
        </div>
      </footer>
    </div>
  );
}

const projects = [
  {
    title: "Projeto 1",
    type: "Design & Desenvolvimento",
    image: "https://images.unsplash.com/photo-1517292987719-0369a794ec0f?auto=format&fit=crop&q=80"
  },
  {
    title: "Projeto 2",
    type: "Design & Desenvolvimento",
    image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&q=80"
  },
  {
    title: "Projeto 3",
    type: "Design & Desenvolvimento",
    image: "https://images.unsplash.com/photo-1535957998253-26ae1ef29506?auto=format&fit=crop&q=80"
  }
];

export default App;